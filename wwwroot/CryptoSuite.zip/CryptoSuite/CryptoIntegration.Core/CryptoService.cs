﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace CryptoIntegration.Core;

public record CryptoPayload(string Data, long UnixTimestamp);

public class CryptoService
{
    // Encrypts text and bakes a live UTC timestamp into the encrypted blob
    public static string Encrypt(string plainText, byte[] key)
    {
        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var payload = new CryptoPayload(plainText, timestamp);
        var json = JsonSerializer.Serialize(payload);
        var plainBytes = Encoding.UTF8.GetBytes(json);

        byte[] nonce = new byte[AesGcm.NonceByteSizes.MaxSize]; // 12 Bytes
        RandomNumberGenerator.Fill(nonce);

        byte[] tag = new byte[AesGcm.TagByteSizes.MaxSize];     // 16 Bytes
        byte[] cipherBytes = new byte[plainBytes.Length];

        using var aesGcm = new AesGcm(key, AesGcm.TagByteSizes.MaxSize);
        aesGcm.Encrypt(nonce, plainBytes, cipherBytes, tag);

        // Merge components into a single array
        byte[] result = new byte[nonce.Length + tag.Length + cipherBytes.Length];
        Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, result, nonce.Length, tag.Length);
        Buffer.BlockCopy(cipherBytes, 0, result, nonce.Length + tag.Length, cipherBytes.Length);

        return Convert.ToBase64String(result);
    }

    // Decrypts payload and completely rejects it if older than maxAgeSeconds
    public static string Decrypt(string base64Cipher, byte[] key, int maxAgeSeconds = 300)
    {
        byte[] fullPacket = Convert.FromBase64String(base64Cipher);
        int nonceSize = AesGcm.NonceByteSizes.MaxSize;
        int tagSize = AesGcm.TagByteSizes.MaxSize;

        if (fullPacket.Length < (nonceSize + tagSize))
            throw new CryptographicException("Malformed ciphertext packet.");

        byte[] nonce = new byte[nonceSize];
        byte[] tag = new byte[tagSize];
        byte[] cipherBytes = new byte[fullPacket.Length - nonceSize - tagSize];

        Buffer.BlockCopy(fullPacket, 0, nonce, 0, nonceSize);
        Buffer.BlockCopy(fullPacket, nonceSize, tag, 0, tagSize);
        Buffer.BlockCopy(fullPacket, nonceSize + tagSize, cipherBytes, 0, cipherBytes.Length);

        byte[] plainBytes = new byte[cipherBytes.Length];
        using var aesGcm = new AesGcm(key, tagSize);
        aesGcm.Decrypt(nonce, cipherBytes, tag, plainBytes);

        var json = Encoding.UTF8.GetString(plainBytes);
        var payload = JsonSerializer.Deserialize<CryptoPayload>(json);

        if (payload == null)
            throw new CryptographicException("Failed to decode internal JSON properties.");

        // Check if the timestamp is within valid window bounds
        var currentTimestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        if (Math.Abs(currentTimestamp - payload.UnixTimestamp) > maxAgeSeconds)
            throw new CryptographicException("Security Alert: The timestamp signature has expired!");

        return payload.Data;
    }
}