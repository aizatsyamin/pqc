(function() {
    
    // Tracking function
    function pushToDataLayer(eventName, eventData) {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'event': eventName,
            ...eventData
        });
    }
    
    function triggerConfetti() {
        if (typeof confetti === 'function') {
            confetti({
                particleCount: 200,
                spread: 100,
                startVelocity: 55,
                origin: { y: 1, x: 0.5 },
                colors: ['#ED1C24', '#FFD700', '#FFFFFF', '#9b1c2e']
            });
            
            setTimeout(() => {
                confetti({
                    particleCount: 120,
                    spread: 80,
                    startVelocity: 60,
                    origin: { y: 1, x: 0.2 },
                    colors: ['#ED1C24', '#FFD700']
                });
            }, 500);
            
            setTimeout(() => {
                confetti({
                    particleCount: 120,
                    spread: 80,
                    startVelocity: 60,
                    origin: { y: 1, x: 0.8 },
                    colors: ['#FFFFFF', '#9b1c2e']
                });
            }, 1000);
            
            setTimeout(() => {
                confetti({
                    particleCount: 150,
                    spread: 120,
                    startVelocity: 70,
                    origin: { y: 1, x: 0.5 },
                    colors: ['#FFD700', '#ED1C24', '#FFFFFF']
                });
            }, 1300);
            
        }
    }
    
    // swiper init
    const swiper = new Swiper(".mySwiper", {
        direction: "vertical",
        loop: true,
        speed: 800,
        autoplay: { delay: 4000, disableOnInteraction: false },
        pagination: { el: ".swiper-pagination", clickable: true },
        mousewheel: { invert: false, sensitivity: 1, releaseOnEdges: true, forceToAxis: true },
        simulateTouch: true,
        grabCursor: true,
        touchRatio: 1,
        resistance: true,
        resistanceRatio: 0.85,
    });

    // data
    let userData = {};
    let rewardValue = 0;
    let currentFlowStep = 0;
    const possibleRewards = [6, 16, 88, 60, 600];
    const flowSteps = ['flowForm', 'flowVoucher', 'flowQuestion', 'flowPicker', 'flowThankYou'];

    // countdown
    const targetDate = new Date("March 20, 2026 23:59:59").getTime();
    function updateCountdown() {
        const now = new Date().getTime();
        const diff = targetDate - now;
        if (diff <= 0) {
            document.getElementById("days").innerText = "00";
            document.getElementById("hours").innerText = "00";
            document.getElementById("mins").innerText = "00";
            document.getElementById("secs").innerText = "00";
            return;
        }
        document.getElementById("days").innerText = Math.floor(diff / (1000 * 60 * 60 * 24)).toString().padStart(2, '0');
        document.getElementById("hours").innerText = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)).toString().padStart(2, '0');
        document.getElementById("mins").innerText = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, '0');
        document.getElementById("secs").innerText = Math.floor((diff % (1000 * 60)) / 1000).toString().padStart(2, '0');
    }
    setInterval(updateCountdown, 1000);
    updateCountdown();

    // flow navigation
    window.startFlow = function() {
        swiper.autoplay.stop();
        swiper.el.style.display = 'none';
        document.querySelector('.swiper-pagination').style.display = 'none';
        showFlowStep(0);
    };

    function showFlowStep(index) {
        flowSteps.forEach(step => document.getElementById(step).classList.remove('active'));
        document.getElementById(flowSteps[index]).classList.add('active');
        currentFlowStep = index;
    }

    function showPopup(message, isError = false) {
        const popup = document.getElementById('popupMessage');
        popup.style.backgroundColor = isError ? '#dc3545' : '#28a745';
        popup.style.color = 'white';
        popup.textContent = message;
        popup.style.display = 'block';
        setTimeout(() => popup.style.display = 'none', 1500);
    }

    // validation (extra layer)
    function validateName(name) { return /^[A-Za-z\s]+$/.test(name); }
    function validatePhone(phone) { return /^\d{10,14}$/.test(phone); }
    function validateNRIC(nric) { return /^\d{12}$/.test(nric); }
    function validatePostcode(postcode) { return /^\d{5}$/.test(postcode); }

    window.submitForm = function() {
        const name = document.getElementById('fullName').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const nric = document.getElementById('nric').value.trim();
        const postcode = document.getElementById('postcode').value.trim();
        const terms = document.getElementById('termsCheck').checked;
        const consent = document.getElementById('consentCheck').checked;
        const certify = document.getElementById('certifyCheck').checked;

        if (!name || !phone || !email || !nric || !postcode) 
            return showPopup('Please fill in all fields', true);
        if (!validateName(name)) 
            return showPopup('Name should only contain letters', true);
        if (!validatePhone(phone)) 
            return showPopup('Phone number must be 10-14 digits', true);
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) 
            return showPopup('Valid email required', true);
        if (!validateNRIC(nric)) 
            return showPopup('NRIC must be 12 digits', true);
        if (!validatePostcode(postcode)) 
            return showPopup('Postcode must be 5 digits', true);
        if (!terms || !consent || !certify) 
            return showPopup('Please agree to all terms', true);

        userData = { name, phone, email, nric, postcode };

        const btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.textContent = 'Submitting...';

        setTimeout(() => {
            rewardValue = possibleRewards[Math.floor(Math.random() * possibleRewards.length)];
        
                    // TRACKING: Form submission with reward value
                    pushToDataLayer('form_submission', {
                        'form_name': 'campaign_registration',
                        'reward_value': rewardValue
                    });
            
            btn.disabled = false;
            btn.textContent = 'Submit';
            showFlowStep(1); // voucher page
        }, 1500);
    };

    window.goToQuestion = function() { showFlowStep(2); };
    window.checkAnswer = function(el, ans) {
        if (ans === '60') {
            el.classList.add('correct');
            document.querySelectorAll('.quiz-option').forEach(opt => opt.style.pointerEvents = 'none');
            setTimeout(() => document.getElementById('correctMessage').style.display = 'block', 500);
        } else {
            el.classList.add('wrong');
            showPopup('Wrong answer! Please try again.', true);
            setTimeout(() => el.classList.remove('wrong'), 500);
        }
    };

    window.goToPicker = function() {
        document.getElementById('cardsBefore').classList.remove('hidden');
        document.getElementById('cardsAfter').classList.remove('active');
        document.querySelectorAll('.card').forEach(c => c.classList.remove('revealed', 'hidden'));
        showFlowStep(3);
    };

    window.pickCard = function(card, idx) {
        if (card.classList.contains('revealed')) return;
        document.querySelectorAll('.card').forEach(c => c.classList.add('hidden'));
        document.getElementById('cardsBefore').classList.add('hidden');
        document.getElementById('cardsAfter').classList.add('active');
        document.getElementById('selectedCard').textContent = `RM${rewardValue}`;
        triggerConfetti();
        
        // TRACKING: Card picked with reward value
        pushToDataLayer('reward_revealed', {
            'reward_value': rewardValue,
            'reward_formatted': `RM${rewardValue}`
        });
    };
    
    window.goToThankYou = function() { 
        // TRACKING: Claim button clicked
        pushToDataLayer('claim_click', {
            'reward_value': rewardValue,
            'reward_formatted': `RM${rewardValue}`
        });
        showFlowStep(4); 
    };  

    // desktop image switch helper (minimal)
    function handleDesktopImages() {
        const isDesktop = window.matchMedia('(min-width: 768px)').matches;
        if (isDesktop) {
            document.querySelectorAll('.flow-container').forEach(c => {
                if (c.classList.contains('bg-2')) c.style.backgroundImage = 'url("../img/bg2a.jpg")';
                else if (c.classList.contains('bg-3')) c.style.backgroundImage = 'url("../img/bg3a.jpg")';
            });
        }
    }
    window.addEventListener('load', handleDesktopImages);
    window.addEventListener('resize', handleDesktopImages);
    
    // extra: block non-digit paste on numeric fields (optional)
    ['phone','nric','postcode'].forEach(id => {
        const field = document.getElementById(id);
        if (field) {
            field.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' || e.key === 'Delete' || e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Tab') return;
                if (e.key < '0' || e.key > '9') e.preventDefault();
            });
            field.addEventListener('paste', (e) => {
                const pasted = (e.clipboardData || window.clipboardData).getData('text');
                if (!/^\d+$/.test(pasted)) e.preventDefault();
            });
        }
    });
    
    // Slider click tracking
    document.querySelectorAll('[data-track="slider-click"]').forEach(element => {
        element.addEventListener('click', function(e) {
            const slideNumber = this.getAttribute('data-slide');
            pushToDataLayer('slider_click', {
                'slide_number': slideNumber,
                'slide_label': `Slide ${slideNumber}`
            });
        });
    });

    // App download tracking
    document.querySelectorAll('[data-track="app-download"]').forEach(element => {
        element.addEventListener('click', function(e) {
            const platform = this.getAttribute('data-platform');
            pushToDataLayer('app_download_click', {
                'platform': platform,
                'store': platform === 'ios' ? 'Apple App Store' : 'Google Play Store'
            });
        });
    });
    
})();